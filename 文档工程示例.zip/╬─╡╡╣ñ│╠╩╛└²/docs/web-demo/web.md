## web脚手架

### 使用说明
通过web脚手架可以快速生成一个定制的web项目框架,web脚手架支持自定义应用名称、应用版本、启动端口等信息，且支持一键生成符合平台规范的应用包。

### 准备
**web脚手架**：web-app-scaffold-0.1.zip
**开发环境**：安装vscode(版本1.92.x)、pnpm(版本9.6.x)、node(版本v20.15.x)、python(版本3.9.x)

### 操作步骤
1. **打开web-app-scaffold-0.1.zip所在的目录**

![main](./assets/images/web-scaffold/1.png ':size=75%')

2. **打开终端**

![main](./assets/images/web-scaffold/2.png ':size=75%')


3. **生成项目框架**

输入cookiecutter命令，生成项目框架。

```
cookiecutter eb-app-scaffold-0.1.zip
```
![main](./assets/images/web-scaffold/3.png ':size=75%')

4. **交互式输入应用信息**

括号中所显示的值为默认值，不输入信息，直接回车时，使用默认值。

 ![main](./assets/images/web-scaffold/4.png ':size=75%')

5. **查看项目文件是否生成**

当前目录下生成名为**web-app**的文件夹，此为依据脚手架生成的项目。

 ![main](./assets/images/web-scaffold/5.png ':size=75%')

6. **使用vscode打开项目**

 ![main](./assets/images/web-scaffold/6.png ':size=75%')

 开发人员可在此项目里开发功能。

 7. **pnpm拉取依赖**

 新建终端，执行如下命令。

 ```
 pnpm i
 ```
 ![main](./assets/images/web-scaffold/7.png ':size=75%')

 8. **生成应用包**

 执行模板中自带的package.py文件，生成应用包。

```
python package.py
```
![main](./assets/images/web-scaffold/8.png ':size=75%')

9. **查看根目录下生成的应用包**

![main](./assets/images/web-scaffold/9.png ':size=75%')