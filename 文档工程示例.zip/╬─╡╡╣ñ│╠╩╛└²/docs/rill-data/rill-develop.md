## 应用开发过程

### 概述

rill 是一个开源项目，其主要存在形式为二进制文件，现在将 rill 作为一个第三方应用集成到平台的典型案例进行说明，整体流程如下：

![main](./assets/images/rill-develop/2.png ':size=75%')


应用包的名称与配置文件appmanifes.ini中的信息相对应，应用包名称为：ID-version，参考规范：<智能软件平台OS应用包及描述配置文件规范-A05>

### 分解命令打包

为了便于理解和学习打包的详细内容，本节提供了打包过程的分解步骤。建议在初次进行打包时按照这些步骤执行，以便深入了解其本质。理解了基本原理之后，有能力的开发人员可以进一步将这些步骤编写成 shell 脚本来自动化这一过程。在文档的下一节[shell脚本打包](#shell脚本打包)中提供了一个打包的 shell 脚本示例及其使用方法，可供开发人员参考，在后续对应用进行升级时建议使用该脚本进行打包操作。

#### 准备阶段
    

*   开发环境 **：** 64位的Linux5.X及以上，例如：Ubuntu22.04LTSServer。
    
*   技术要求：①掌握linux基本命令的编写，如：ll、cd、touch、mkdir、tar、vim；②具备编写shell脚本的能力。
    
*   知悉开发环境的用户名和密码。
    
*   将rill二进制文件拷贝到开发环境的某个目录下。

*   登录开发环境。


[](./assets/videos/rill-develop/develop1.mp4 ':include width=80% controls') 

#### 实操阶段

1. **创建根目录**
    

```powershell
mkdir appmake #创建目录
cd appmake #进入目录
```

2.  **创建app目录**
    
```powershell
mkdir rill-0.0.1
cd rill-0.0.1 #进入目录
```

3.  **创建bin目录**
    
```powershell
mkdir bin
cd bin #进入目录
```

4. **拷贝rill到当前目录**
    
```powershell
cp /usr/local/bin/rill ./ 
#/usr/local/bin为提前存放rill二进制文件的目录
```

5.  **创建start.sh脚本** <a id="start"></a>
    
```powershell
touch start.sh#创建一个空文件
vim start.sh #复制脚本内容后，推出编辑状态：qw
```

**脚本内容**

start.sh的模板见 [附件1](#附件1)

```powershell
#!/bin/bash
export HOME=/root
hsm_home=$HSM_HOME
#获取平台的安装根目录
if [ -z "$hsm_home" ]; then
        hsm_home="/usr/local/os"
fi
#创建应用的数据目录统一在：根目录/data/应用Id
mkdir -p $hsm_home/data/rill
echo "==============================start rill==========================="
#启动应用的主要命令
nohup ./rill start $hsm_home/data/rill/hsm_rill > /dev/null 2>&1 &
#使用$!获取上述启动的进程pid，写入到bin目录（当前目录）下，以appmanifest.ini文件中配置的主程序名称为前缀，以.pid结束。此为硬性要求。
echo $! > ./rill.pid
#集成到portal-若应用需要集成到portal，可脚本执行初始化操作，也可在代码里执行。
if [ ! -f "init.sh" ]; then
        echo "init.sh文件不存在，集成到portal失败"
fi
if [ ! -f "mnmu.json" ]; then
        echo "menu.json不存在，无法初始化数据，集成到portal失败"
fi
#初始化数据，集成到统一门户
./init.sh

echo "==============================   success ========================="
```

6.  **创建stop脚本** <a id="stop"></a>
    

```powershell
touch stop.sh
vim stop.sh #复制脚本内容后，推出编辑状态：qw
```

**脚本内容**

stop.sh的模板见 [附件2](#附件2)
```powershell
#!/bin/bash
echo "==========start to kill rill $(date +"%Y-%m-%d %T")==========================="
#pid文件
rill_pidfile=./rill.pid
echo "pid文件路径$rill_pidfile"
if [ -f $rill_pidfile ]; then
        echo "rill pidfile exists"
        #获取pid
        rill_pid=$(cat $rill_pidfile)
        echo "rill pid is $rill_pid"
        #kill pid
        kill -quit $rill_pid
        echo "kill rill succeed"
fi
```

7.  **创建初始化脚本** <a id="init"></a>
    

为了将应用集成到统一门户中，需要通过统一门户的菜单注册接口进行数据初始化。为此，需要准备一个初始化脚本和一个包含初始化数据的文件。菜单注册接口链接：待补充

```powershell
touch init.sh
```

<details>
<summary>脚本内容</summary>
<p>

```powershell
#!/bin/bash

if [ ! -f "./menu.json" ]; then
 echo "菜单文件不存在"
 return
fi
#集成到portal使用的接口
url="http://localhost:6200/api/graphql/"
if [ -z "$url" ]; then
 echo "url为空"
 return
fi

# 读取数据，menu.json为接口数据-集成到portal菜单的请求数据
DATA=$(cat ./menu.json)

echo $DATA

# set headers
headers="Content-Type: application/json"

# 发送请求-调用权限的接口进行应用和菜单的注册
request_data='{"operationName":"import", "variables": '"$DATA"', "query": "mutation import($data: ImportReqInfo!) { import(data: $data) { data }}"}'

response=$(curl -s -X POST $url -H "$headers" -d "$request_data")

# 解析响应
echo "$response"
if echo $response | grep -q 'true'; then
 echo "导入成功"
else
 echo "导入失败"
fi

```

</p>
</details>

8.  **初始化数据** <a id="menu"></a>

准备初始化数据，集成至统一门户系统，在门户界面生成相应的菜单入口。
    
```powershell
touch menu.json
```

**数据内容**

```json
{
  "data": {
    "apps": [
      {
        "id": "data-analyse-platform",
        "applicationCode": "data-analyse-platform",
        "applicationName": "实时数据分析平台",#应用信息注册，可替换为你的应用名称，会显示在portal的左侧菜单的首层目录里
        "i18n": "",
        "applicationType": 1,
        "isOtherApplication": false,
        "visitUrl": null,
        "imageUrl": "",
        "authType": "1",
        "componentPath": null,
        "routeType": 1,
        "openStyle": 1,
        "description": "",
        "clientId": "data-analyse-platform",
        "clientSecret": "",
        "callbackUrl": "",
        "accessTokenOverUnit": 1,
        "accessTokenOverValue": 2,
        "refreshTokenOverUnit": 1,
        "refreshTokenOverValue": 4,
        "displayNavigation": true,
        "sort": 1000,
        "menuInfos": [
          {
            "id": "data-analyse",
            "status": true,
            "code": "data-analyse",
            "name": "数据分析",                   #应用下的菜单注册名称
            "parentId": null, 
            "applicationId": "data-analyse-platform",
            "menuType": 2,
            "icon": "",
            "url": "http://${currentIp}:9009/welcome",#配置菜单访问的url
            "openStyle": null,
            "i18n": "",
            "componentPath": null,
            "sort": 1,
            "remark": "",
            "displayNavigation": true,
            "operateGroups": []
          }
        ]
      }
    ]
  }
}
```

9.  **赋予可执行权限**
    
```powershell
chmod +x start.sh stop.sh init.sh
```

10.  **压缩里层压缩包**
    
```powershell
cd ../.. #退出至rill-0.0.1目录外
tar -zcvf rill-0.0.1-tar.gz rill-0.0.1
rm -r rill-0.0.1 #删除原文件夹
```


11.  **创建外层目录**
    

```powershell
mkdir rill-0.0.1 #创建外层目录rill-0.0.1 
cd rill-0.0.1    #进入此目录下进行以下的操作
```


12.  **拷贝里层压缩包**

```powershell
cp ../rill-0.0.1.tar.gz ./ #拷贝里层压缩包rill-0.0.1.tar.gz到此目录下
```

13.  **创建appmanifest.ini文件** <a id="appmanifest"></a>

参考《智能软件平台OS应用包及描述配置文件规范》文档进行编写
    

```powershell
touch appmanifest.ini
vim appmanifest.ini #复制以下配置内容后，推出编辑状态：qw
```

**配置内容**

```ini
#基本信息
[info]
#应用Id
 ID = "rill"
#应用显示名称
 name = "rill"
#应用类型（legacy-传统应用；container-容器应用）
 type = "legacy"
#版本号
 version = "0.0.1"
#行业解决方案
 solution = ""
 certFile = ""
 fingerprintFile = ""
 funcDesc = "实时数据分析平台"
 releaseNote = "实时数据处理、数据源集成、可视化界面、sql查询等"
 source = "Hollysys"
#应用兼容模式（standard-标准应用；custom-定制化应用）
 appMode = "standard"
#严格模式（true-严格模式；false-正常模式）
 strictMode = false
#支持Linux系统的发行版类型
 supSysType = []
 appsets = "数据分析"
#device-model依赖postgresql数据库
[package]
#安装程序信息
#容器内的目录列表
targetPaths = []
#安装脚本文件名称
 installProgramName = ""
#安装参数
 installParams = []
#卸载脚本文件名称
 unInstallProgramName = ""

[execute]
#运行信息
#建议核数大小
 cpuLimit = ""
#建议内存大小
 memoryLimit = ""
#程序类型(java、exec、web、dotnet、nodejs、python、container)
 programType = "exec"
#是否特权模式运行,默认false
 privileged = false
#启动文件名称
 startProgramName = "bin/start.sh"
#启动参数
 startParams = []
#停止文件名称
 stopProgramName = "bin/stop.sh"
#数据存储目录列表
 dataDir = []


#运行时提供环境变量
[execute.env]
#守护和健康检查配置
[[execute.programs]]
#程序名 mes文件要存在，启动脚本里要拿到程序启动的pid,并将其写入到mes.pid文件里。
 progName = "bin/rill"
#程序参数
 progParams = []
#程序是否需要守护（true-不需要守护；false-需要守护），默认false
 notNeedGuard = false
#健康检查，默认GET请求
 healthCheckReadyType = ""
 healthCheckReadyInterface = ""
 healthCheckReadyHttpPort = ""
```

**配置文件常用字段说明**

*   **ID** ： 应用的英文名称。
    
*   **name** ：应用的中文名称。
    
*   **type**：应用类型，legacy-传统应用；container-容器应用。
    
*   **version**：应用版本，与ID组合成应用包的名称，规则：ID-version。
    
*   **appsets**：应用集名称，为了确保一个Web应用的前端与后端组件能够被有效地管理和组织，建议采用“应用集”的概念进行分类与整合。
    
*   **startProgramName**：启动脚本文件的相对路径，按照规范存放至bin目录下。
    
*   **stopProgramName**：停止脚本文件的相对路径，按照规范存放至bin目录下。
    
*   **progarams**：主程序的名称，需要与启动脚本中生成的pid文件对应，按照示例，启动脚本中生成的pid文件名称为：rill.pid，按照规范存放至bin目录下。
    

14.  **压缩外层目录**
    
```powershell
cd ..       #退出到rill-0.0.1目录外
tar -zcvf rill-0.0.1-tar.gz rill-0.0.1
```


[](./assets/videos/rill-develop/develop2.mp4 ':include width=80% controls')


### shell脚本打包 
    
为了提高打包效率并确保打包过程的一致性，建议将上一节 [打包分解步骤](#打包分解步骤) 中详述的打包步骤集成到一个 shell 脚本中，以实现自动化打包。这样不仅可以简化后续升级应用包的过程，还能减少手动操作带来的潜在错误。


#### 准备文件

为了确保所有相关文件能够被正确地组织和管理，要求将第二节中提到的脚本文件和二进制文件统一存放在同一个目录下，文件如下：

* **[start.sh](#start)**: 用于启动应用的脚本文件。
* **[stop.sh](#stop)**: 用于停止应用的脚本文件。
* **[init.sh](#init)**: 用于初始化应用的脚本文件。
* **[menu.json](#menu)**: 包含应用菜单信息的JSON文件。
* **[appmanifest.ini](#appmanifest)**: 包含应用配置信息。

![main](./assets/images/rill-develop/1.png ':size=75%')


#### 编辑shell脚本

shell脚本的内容包括：①读取配置文件中的应用ID和版本号信息、②判断文件的存在性、③打包。

**创建脚本文件**

```
touch make.sh
vim make.sh
```

**脚本内容**


```powershell
#!/bin/bash

# 判断配置文件是否存在
if [ ! -f "appmanifest.ini" ]; then
        echo "appmanifest.ini不存在"
        exit 1
fi
sed 's/\r$//' appmanifest.ini > appmanifest.ini.unix
mv appmanifest.ini.unix appmanifest.ini
#从配置文件中解析应用ID和版本，为了后续打包时创建应用包名称的文件夹
appId=$(grep '^ ID =' appmanifest.ini | awk -F'=' '{print $2}' | xargs)
version=$(grep '^ version =' appmanifest.ini | awk -F'=' '{print $2}' | xargs)
# 检查变量是否为空
if [ -z "$appId" ]; then
    echo "错误：请传递参数 appId。"
    exit 1
fi

if [ -z "$version" ]; then
    echo "错误：请传递参数 version。"
    exit 1
fi

# 判断 start.sh 文件是否存在
if [ -f "start.sh" ]; then
    chmod +x start.sh
else
    echo "start.sh 脚本不存在"
    exit 1
fi

# 判断 rill 文件是否存在
if [ ! -f "rill" ]; then
    echo "rill 二进制文件不存在"
    exit 1
fi

# 判断 stop.sh 文件是否存在
if [ -f "stop.sh" ]; then
    chmod +x stop.sh
else
    echo "stop.sh 脚本不存在"
    exit 1
fi
if [ -f "init.sh" ]; then
        chmod +x init.sh
else
        echo "初始化脚本init.sh不存在"
        exit 1
fi
if [ ! -f "menu.json" ]; then
        echo "初始化数据文件menu.json不存在"
        exit 1
fi

#打包开始
# 创建 bin 目录
mkdir -p bin

# 复制脚本和二进制文件到 bin 目录
cp start.sh stop.sh rill menu.json init.sh bin/

# 创建版本目录
mkdir -p "${appId}-${version}"

# 复制 bin 目录下的文件到版本目录
cp -r ./bin "${appId}-${version}/"

# 创建 tar 文件
tar czf "${appId}-${version}.tar.gz" "${appId}-${version}"

# 清理临时文件
rm -rf "${appId}-${version}" bin
mkdir -p "${appId}-${version}"

# 复制 appmanifest.ini 到版本目录
cp appmanifest.ini "${appId}-${version}.tar.gz" "${appId}-${version}/"

# 最终的 tar 文件应该只包含 appmanifest.ini 和 tar 包本身
tar czf "${appId}-${version}.tar.gz" "${appId}-${version}"

# 清理临时文件
rm -r  "${appId}-${version}"
```

3. 执行make.sh生成

```powershell
./make.sh
```


[](./assets/videos/rill-develop/develop3.mp4 ':include width=75% controls')


### 附件
#### 附件1

start.sh模板 

```powershell
#!/bin/bash

#获取或自定义一些需要使用的变量
#比如获取变量，使用$，HSM_HOME是平台执行该脚本时，注入的环境变量
hsm_home=$HSM_HOME

#启动应用的主要命令，比如启动一个二进制可执行文件xxx
nohup ./xxx > /dev/null 2>&1 &

#使用$!获取上述启动的进程pid，写入到bin目录（当前目录）下，以appmanifest.ini文件中配置的主程序名称yyy为前缀，以.pid结束,此为硬性要求。
echo $! > ./yyy.pid

```
**引用处**：[创建start.sh脚本](#start)

#### 附件2

stop.sh模板

```powershell
#!/bin/bash

#定义pid文件路径变量，此为启动脚本中生成的，如：
rill_pidfile=./rill.pid

#启动文件存在时进行kill
if [ -f $rill_pidfile ]; then
       
        #读取配置文件，获取进程pid，使用cat命令，
        rill_pid=$(cat $rill_pidfile)

        #kill pid
        kill -quit $rill_pid
fi
```
**引用处**：[创建stop.sh脚本](#stop)