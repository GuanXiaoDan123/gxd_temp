##  应用功能说明

### 概述

rill 是一个开源的实时数据分析平台，它允许用户快速构建、部署和管理实时数据管道。rill 提供了一个易于使用的界面，使得数据工程师和分析师能够轻松地处理大量实时数据流，并从中提取有价值的信息。

### 主要功能

1.  **实时数据处理**：
    
    * rill 支持实时数据流处理，可以处理来自多个数据源的实时数据流，并进行实时分析。
        
2.  **数据源集成**：
    
    * rill 支持多种数据源，包括数据库、消息队列、文件系统等，可以轻松地集成各种数据源。
        
3.  **可视化界面**：
    
    * rill 提供了一个用户友好的界面，使得非技术人员也能构建复杂的数据管道。
        
4.  **SQL 查询**：
    
    * 用户可以使用 SQL 语法来查询和处理数据，简化了数据处理的过程。
        
5.  **自动化部署**：
    
    * rill 支持自动化部署，可以轻松地将数据管道部署到生产环境中。
        
6.  **扩展性和可伸缩性**：
    
    *   rill 设计为高度可扩展和可伸缩的，可以处理大量数据和高并发场景。
        
7.  **监控和警报**：
    
    *   rill 提供了监控和警报功能，可以实时监控数据管道的状态，并在发生异常时发出警报。
        
8.  **安全性**：
    
    *   rill 支持多种安全措施，包括数据加密、身份验证和授权，确保数据的安全性和隐私。
        

### 使用说明

rill 提供了全面的数据源集成功能，支持多种类型的数据源接入，包括但不限于关系型数据库（如 PostgreSQL、SQLite 和 MySQL）以及本地文件（如 CSV 格式的文本数据）。下面是使用 PostgreSQL 数据源作为示例的集成流程，此过程同样适用于其他类型的数据库及本地文件。

1.  **访问rill**

登录统一门户，选择左侧“实时数据分析平台”，选择“数据分析”菜单。


![main](./assets/images/rill-function/1.png ':size=75%')


2.  **选择数据源类型**

点击 "Add data" , 选择 PostgreSQL
    

![main](./assets/images/rill-function/dc44191f127e7e2dff71e0ac38ad0612_68567d12-fbea-4cfc-bbb1-a3add3e3d355.png ':size=75%')

3.  **配置连接信息**

![main](./assets/images/rill-function/2.png ':size=75%')


**输入**：

*   **SQL** ：输入连接的PostgreSQL数据库的查询语句，如：select \* from \“MenuInfo\”;
    
*   **Source name** : 输入数据源名称，如：memu\_info\_source 
    
*   **Postgres Connection string** : 输入连接信息，如：postgresql://postgres:postgres\@192.168.0.110:7654/auth\_db
    
数据源连接信息配置完成后，点击右下角的"Add data"按钮，跳转至步骤4中的界面。
    

4.  **数据展示**


![main](./assets/images/rill-function/437a275571240ed95a793b77280fde27_40d5ccc8-afb4-4513-acd1-00ff6f3718b5.png ':size=75%')


以上为统一门户中配置的所有菜单数据，通过此功能，可以获取详细的菜单结构信息。


5.  **创建model**
    

点击界面右上角的"Create model"按钮用于启动模型创建流程，成功点击"Create model"后，将在左侧菜单栏的"Models"列表中自动生成一条新的模型记录，通过点击新生成的模型记录进入模型编辑页面，在此页面内进行SQL语句的编写和调整，以便查询所需的数据内容。


![main](./assets/images/rill-function/3fbd6e9cdcfa116578cfc0335c73ecee_d79a1180-b64a-4598-9f3f-de78fb097edc.png ':size=75%')


如：为了查询"系统管控"应用下的所有菜单项，可以使用以下标准 SQL 查询语句：
```
select \* from my\_new\_source where applicationId= 'hsm-smc'
```

![main](./assets/images/rill-function/32b817dd77316feec5d0f356505fab5a_f76afd42-b1d5-4b7a-b19c-568881253dc0.png ':size=75%')

通过这一流程，用户可以高效地在所选数据源上定义和构建定制化的数据查询模型，从而实现对特定数据集的有效分析和利用。

6.  **数据导出**

点击界面右上角的"Export"按钮用于启动数据导出流程,选择 CSV 格式以将查询结果导出为本地文件,导出后的 CSV 文件可用于数据备份以及进一步的问题排查和分析.


![main](./assets/images/rill-function/0821e3a8daf6783a67418921d78f14ae_0b39da9c-e880-431c-ba4d-9f3a54afa552.png ':size=75%')


7.  **生成看板**  

点击用户界面右上角的"Generate dashboard with AI"选项来启动看板的自动生成过程,在看板生成完成后，将在左侧菜单栏中的"Dashboards"列表内生成一条新的记录，这代表新生成的看板。


![main](./assets/images/rill-function/c9516dfe279535309f7ac63a4395e6d0_4e682372-9408-48a4-98bf-f28b23185307.png ':size=75%')


为了查看生成的看板，请点击用户界面右上角的“Preview”按钮。


![main](./assets/images/rill-function/ee547cc82343de6f6656d0e453aaadb5_93151f5e-20a8-40c3-9aef-c28f8dba0b4c.png ':size=75%')


8.  **调整看板**

为了实现对日志监视下各菜单项的统计以及进一步的数据分析，可以通过界面配置参数，查看每个菜单项的名称及其对应的路由地址。

![main](./assets/images/rill-function/7909c2eb70b80a40f510e52e93aabc20_adc1077f-2a56-44c2-8453-d6ca2edbf553.png ':size=75%')


[](./assets/videos/rill-function/function.mp4 ':include width=80% controls')