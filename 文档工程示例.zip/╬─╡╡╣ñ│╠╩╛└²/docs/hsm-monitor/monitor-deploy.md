## 应用包发布

### 概述

完成rill应用的开发与打包后，下一步是将打包的应用包上传至应用仓库，以便进行统一管理和分发使用。

应用仓库支持基于平台开发的应用与第三方应用的发布与集中管理，产品可根据项目需要挑选适合的应用，进行灵活编排模板构建生成一套解决方案，进而快速生成可部署的应用大包，为现场环境提供即时可用的解决方案，加速了应用的部署流程与市场响应能力。

### 应用包发布

1.   **进入应用仓库**
 
![main](./assets/images/rill-deploy/1.png ':size=75%')
2.  **上传软件包**

进入软件包管理页面，点击”上传软件包“按钮。
    
![main](./assets/images/rill-deploy/2.png ':size=75%')


3.  **点击上传**

选择行业类型和所属分类后，点击“上传”按钮。
    
![main](./assets/images/rill-deploy/3.png ':size=75%')

4.   **选择应用包**

选择要上传的本地软件包.点击“打开”按钮。
 
![main](./assets/images/rill-deploy/4.png ':size=75%')

5.   **上传**

点击”上传“按钮，开始上传
    
![main](./assets/images/rill-deploy/5.png ':size=75%')

实时查看应用上传进度：
 
![main](./assets/images/rill-deploy/6.png ':size=75%')


6.   **查看软件包列表**

查看上传结果，点击”返回“按钮，返回至软件包管理页面。
    
 
![main](./assets/images/rill-deploy/7.png ':size=75%')

软件包列表查询页面查看rill应用包上传结果：

![main](./assets/images/rill-deploy/8.png ':size=75%')


[](./assets/videos/rill-deploy/deploy.mp4 ':include width=80% controls')


