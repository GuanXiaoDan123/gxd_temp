## 应用开发过程

### 概述

随着信息技术的快速发展，系统的复杂度和规模不断增大，对于其性能和稳定性的要求也日益提升。为了确保一个项目的高效运作，并能够实时掌握数据库等中间件的运行状态，我们引入了Telegraf作为核心组件，开发了中间件监控应用，实现了对PostgreSQL（简称PG库）和Redis数据库的深度监控。

![main](./assets/images/monitor-develop/0.png ':size=75%')

### 前端开发

待补充

### 后端开发

#### 功能开发


1. 新建项目，实现后端接口功能开发。


![main](./assets/images/monitor-develop/1.png ':size=75%')

2. 引入Telegraf，开发其启动和停止功能。

![main](./assets/images/monitor-develop/2.png ':size=75%')

3. 准备用于生成Telegraf监控配置文件的模板。

![main](./assets/images/monitor-develop/3.png ':size=75%')


#### 应用配置文件

创建appmanifest.ini文件，配置应用信息供部署工具和系统内核进行安装和启动时使用。

1. 基本信息

```ini
#基本信息
[info]
#应用Id
 ID = "hsm-monitor"
#应用显示名称
 name = "中间件监控"
#应用类型（legacy-传统应用；container-容器应用）
 type = "legacy"
#版本号
 version = "0.1.1"
 #功能说明
 funcDesc = "中间件实时数据监控平台"
 #发布说明
 releaseNote = "监控postgres,redis等数据库指标数据"
 #来源
 source = "Hollysys"
#应用兼容模式（standard-标准应用；custom-定制化应用）
 appMode = "standard"
#严格模式（true-严格模式；false-正常模式）
 strictMode = false
 #应用集名称
 appsets = "监控"

```
2. 运行信息

```ini
#运行信息
[execute]
#建议核数大小
 cpuLimit = ""
#建议内存大小
 memoryLimit = ""
#程序类型(java、exec、web、dotnet、nodejs、python、container)
 programType = "exec"
#是否特权模式运行,默认false
 privileged = false
#启动文件名称
 startProgramName = "bin/start.sh"
#启动参数
 startParams = []
#停止文件名称
 stopProgramName = "bin/stop.sh"
```

3. 健康检查配置

```ini
#守护和健康检查配置
[[execute.programs]]
#程序名 文件要存在，启动脚本里要拿到程序启动的pid,并将其写入到xxx.pid文件里。
 progName = "bin/database-monitor"
#程序参数
 progParams = []
#程序是否需要守护（true-不需要守护；false-需要守护），默认false
 notNeedGuard = false
```

#### 启动脚本

提供应用的启动脚本，供系统内核启动应用时使用。

```powershell
#获取平台安装目录
hsm_home=$HSM_HOME
if [ -z "$hsm_home" ]; then
  hsm_home="/usr/local/hsm-os"
fi
mkdir -p $hsm_home/logs/hsm-monitor
#启动
echo "========================  start hsm-monitor ================================"
nohup ./database-monitor --config ../config/config.yml > /dev/null 2>&1 &
#记录pid
echo $! > ./database-monitor.pid
echo "========================       success       ================================"
```
#### 停止脚本

提供应用的停止脚本，供系统内核停止应用时使用。

```powershell
#获取pid文件
hsm_monitor_pidfile=./database-monitor.pid
telegraf_pidfile=../config/telegraf.pid
#停止主程序
if [ -f $hsm_monitor_pidfile ]; then
    echo "hsm-monitor pidfile exists, kill it now $(date +"%Y-%m-%d %T")"
    hsm_monitor_pid=$(cat $hsm_monitor_pidfile)
    kill -quit $hsm_monitor_pid
    echo "kill hsm-monitor succeed $(date +"%Y-%m-%d %T")"
fi
#停止telegraf
if [ -f $telegraf_pidfile ]; then
    echo "telegraf pidfile exists, kill it now $(date +"%Y-%m-%d %T")"
    telegraf_pid=$(cat $telegraf_pidfile)
    kill -quit $telegraf_pid
    echo "kill telegraf succeed $(date +"%Y-%m-%d %T")"
fi

```
#### 集成到统一门户
通过注册应用和菜单的方式，将应用集成到统一门户。

1. 注册脚本

```powershell

#!/bin/bash

if [ ! -f "./menu.json" ]; then
 echo "菜单文件不存在"
 return
fi
#集成到portal使用的接口
url="http://localhost:6200/api/graphql/"
if [ -z "$url" ]; then
 echo "url为空"
 return
fi

# 读取数据，menu.json为接口数据-集成到portal菜单的请求数据
DATA=$(cat ./menu.json)

echo $DATA

# set headers
headers="Content-Type: application/json"

# 发送请求-调用权限的接口进行应用和菜单的注册
request_data='{"operationName":"import", "variables": '"$DATA"', "query": "mutation import($data: ImportReqInfo!) { import(data: $data) { data }}"}'

response=$(curl -s -X POST $url -H "$headers" -d "$request_data")

# 解析响应
echo "$response"
if echo $response | grep -q 'true'; then
 echo "导入成功"
else
 echo "导入失败"
fi
```

2. 注册数据

```powershell
{
    "data": {
      "apps": [
        {
          "id": "monitor-platform",
          "applicationCode": "monitor-platform",
          "applicationName": "中间件监控系统",
          "i18n": "",
          "applicationType": 1,
          "isOtherApplication": false,
          "visitUrl": null,
          "imageUrl": "",
          "authType": "1",
          "componentPath": null,
          "routeType": 1,
          "openStyle": 1,
          "description": "",
          "clientId": "monitor-platform",
          "clientSecret": "",
          "callbackUrl": "",
          "accessTokenOverUnit": 1,
          "accessTokenOverValue": 2,
          "refreshTokenOverUnit": 1,
          "refreshTokenOverValue": 4,
          "displayNavigation": true,
          "sort": 1000,
          "menuInfos": [
            {
              "id": "monitor-analyse",
              "status": true,
              "code": "monitor-analyse",
              "name": "中间件监控",                   
              "parentId": null, 
              "applicationId": "monitor-platform",
              "menuType": 2,
              "icon": "",
              "url": "http://${currentIp}:9009/welcome",
              "openStyle": null,
              "i18n": "",
              "componentPath": null,
              "sort": 1,
              "remark": "",
              "displayNavigation": true,
              "operateGroups": []
            }
          ]
        }
      ]
    }
  }
  
```
#### 应用打包

按照平台应用包规范制作应用包，结构如下：

![main](./assets/images/monitor-develop/4.png ':size=75%')

应用打包脚本如下：

```powershell
# 判断配置文件是否存在
if [ ! -f "appmanifest.ini" ]; then
        echo "appmanifest.ini不存在"
        exit 1
fi
sed 's/\r$//' appmanifest.ini > appmanifest.ini.unix
mv appmanifest.ini.unix appmanifest.ini
#从配置文件中解析应用ID和版本，为了后续打包时创建应用包名称的文件夹
appId=$(grep '^ ID =' appmanifest.ini | awk -F'=' '{print $2}' | xargs)
version=$(grep '^ version =' appmanifest.ini | awk -F'=' '{print $2}' | xargs)
# 检查变量是否为空
if [ -z "$appId" ]; then
    echo "错误：请传递参数 appId。"
    exit 1
fi

if [ -z "$version" ]; then
    echo "错误：请传递参数 version。"
    exit 1
fi

# 判断 start.sh 文件是否存在
if [ -f "start.sh" ]; then
    chmod +x start.sh
else
    echo "start.sh 脚本不存在"
    exit 1
fi

# 判断 database-monitor 文件是否存在
if [ ! -f "database-monitor" ]; then
    echo "database-monitor 二进制文件不存在"
    exit 1
fi

# 判断 stop.sh 文件是否存在
if [ -f "stop.sh" ]; then
    chmod +x stop.sh
else
    echo "stop.sh 脚本不存在"
    exit 1
fi
if [ -f "init.sh" ]; then
        chmod +x init.sh
else
        echo "初始化脚本init.sh不存在"
        exit 1
fi
if [ ! -f "menu.json" ]; then
        echo "初始化数据文件menu.json不存在"
        exit 1
fi

#打包开始
# 创建 bin 目录
mkdir -p bin

# 复制脚本和二进制文件到 bin 目录
cp start.sh stop.sh rill menu.json init.sh bin/

# 创建版本目录
mkdir -p "${appId}-${version}"

# 复制 bin 目录下的文件到版本目录
cp -r ./bin "${appId}-${version}/"

# 创建 tar 文件
tar czf "${appId}-${version}.tar.gz" "${appId}-${version}"

# 清理临时文件
rm -rf "${appId}-${version}" bin
mkdir -p "${appId}-${version}"

# 复制 appmanifest.ini 到版本目录
cp appmanifest.ini "${appId}-${version}.tar.gz" "${appId}-${version}/"

# 最终的 tar 文件应该只包含 appmanifest.ini 和 tar 包本身
tar czf "${appId}-${version}.tar.gz" "${appId}-${version}"

# 清理临时文件
rm -r  "${appId}-${version}"
```







