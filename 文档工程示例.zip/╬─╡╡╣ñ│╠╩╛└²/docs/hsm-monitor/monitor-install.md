## 安装部署
### 概述

从应用仓库下载所需的应用包文件，使用适当的介质（如USB闪存盘）将应用包文件拷贝到工程师站的目标目录中。登录工程配置环境，进入到安装部署模块，进行应用的安装。


### 下载

1.   **点击下载**

登录应用仓库系统，进入软件包管理页面，选择rill应用包，点击”展开“按钮。


![main](./assets/images/rill-deploy/10.png ':size=75%')


2.   **选择下载目录**
    

![main](./assets/images/rill-deploy/11.png ':size=75%')


在浏览器下载记录中，查看已下载的应用包：

![main](./assets/images/rill-deploy/12.png ':size=75%')


3. **传输应用包**

使用优盘或其他介质将应用包拷贝到工程配置环境所在服务器的home路径下，若服务器之间可使用scp传输数据时，也可使用如下命令进行应用包的拷贝操作。
```
##在应用包所在目录下打开终端
scp ./rill-0.0.1.tar.gz root@ip:/home 
##ip替换为工程配置环境的真实ip
```

[](./assets/videos/rill-install/install1.mp4 ':include width=80% controls')

### 安装

1.  **登录工程配置环境**

输入ip:8000,登录平台的工程配置环境,打开项目。

![main](./assets/images/rill-install/0.png ':size=75%')

2. **打开系统部署界面**

![main](./assets/images/rill-install/1.png ':size=75%')

3.  **应用导入**

点击应用导入，选择下载的路径，点击应用导入。
    
![main](./assets/images/rill-install/2.png ':size=75%')


4.  **添加应用**

点击服务器上的添加按钮，勾选应用，点击保存。
    
![main](./assets/images/rill-install/3.png ':size=75%')

5.  **安装应用**

点击服务器上的升级按钮，进入安装界面，选择应用，点击操作栏中的安装按钮，安装应用。
    
![main](./assets/images/rill-install/4.png ':size=75%')

6.  **访问统一门户**

输入ip,访问统一门户，点击左侧菜单，访问数据分析平台。

![main](./assets/images/rill-install/5.png ':size=75%')


[](./assets/videos/rill-install/install.mp4 ':include width=80% controls')
